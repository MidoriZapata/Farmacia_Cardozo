<?php
session_start();
$id_user = $_SESSION['idUser'];

include "../conexion.php";

// Si no viene id de usuario, redirigir
if (empty($_GET['id'])) {
    header("Location: usuarios.php");
}
$id = $_GET['id'];

// Evitar que usuarios sin permiso entren aquí
$permiso = "usuarios";
$sql = mysqli_query($conexion, "SELECT p.*, d.* 
                                FROM permisos p 
                                INNER JOIN detalle_permisos d 
                                ON p.id = d.id_permiso 
                                WHERE d.id_usuario = $id_user 
                                AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header("Location: permisos.php");
}

// Guardar permisos
if (!empty($_POST)) {
    $user_id = $_POST['user_id'];

    // Eliminar permisos actuales
    mysqli_query($conexion, "DELETE FROM detalle_permisos WHERE id_usuario = $user_id");

    // Guardar los seleccionados
    if (!empty($_POST['permisos'])) {
        foreach ($_POST['permisos'] as $perm) {
            mysqli_query($conexion, "INSERT INTO detalle_permisos(id_usuario,id_permiso) VALUES ($user_id,$perm)");
        }
    }

    echo '<script>
        alert("Permisos actualizados correctamente");
        window.location="usuarios.php";
    </script>';
}

// Obtener permisos actuales del usuario
$perm_actuales = mysqli_query($conexion, "SELECT id_permiso FROM detalle_permisos WHERE id_usuario = $id");
$permisos_usuario = [];
while ($row = mysqli_fetch_assoc($perm_actuales)) {
    $permisos_usuario[] = $row['id_permiso'];
}

// Obtener lista de permisos disponibles
$lista = mysqli_query($conexion, "SELECT * FROM permisos");

include "includes/header.php";
?>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h4>Asignar Permisos al Usuario #<?php echo $id; ?></h4>
    </div>

    <div class="card-body">

        <form method="post" action="">
            <input type="hidden" name="user_id" value="<?php echo $id; ?>">

            <div class="row">

                <?php while ($p = mysqli_fetch_assoc($lista)) { ?>
                    <div class="col-md-3 mb-2">
                        <label class="form-check-label">
                            <input type="checkbox" 
                                   name="permisos[]" 
                                   value="<?php echo $p['id']; ?>"
                                   class="form-check-input"
                                   <?php echo in_array($p['id'], $permisos_usuario) ? "checked" : ""; ?>>
                            <?php echo $p['nombre']; ?>
                        </label>
                    </div>
                <?php } ?>

            </div>

            <button type="submit" class="btn btn-success mt-3">Guardar Permisos</button>
            <a href="usuarios.php" class="btn btn-secondary mt-3">Volver</a>
        </form>

    </div>
</div>

<?php include "includes/footer.php"; ?>
