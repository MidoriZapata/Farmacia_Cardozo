<?php
session_start();
require '../conexion.php';

// Solo ejecutarlo si el usuario está logueado
if (empty($_SESSION['active'])) {
    exit("No autorizado");
}

$hoy = date('Y-m-d');

// Obtener productos con alerta hoy o que vencen hoy
$query_alertas = mysqli_query($conexion, "
    SELECT descripcion, fecha_alerta, vencimiento 
    FROM producto 
    WHERE fecha_alerta = '$hoy' OR vencimiento = '$hoy'
");

$apiKey = "bvg6bcxwweiofm32w6ycgpt3t"; // Reemplaza con tu REST API Key
$appId = "f5a9cab9-dafe-4e13-b93e-0548ca9b5632"; // Tu App ID

while ($producto = mysqli_fetch_assoc($query_alertas)) {
    $mensaje = "";

    if ($producto['vencimiento'] == $hoy) {
        $mensaje = "El producto {$producto['descripcion']} vence hoy!";
    } elseif ($producto['fecha_alerta'] == $hoy) {
        $mensaje = "Alerta: El producto {$producto['descripcion']} está por vencer el {$producto['vencimiento']}.";
    } else {
        continue;
    }

    $fields = [
        'app_id' => $appId,
        'included_segments' => ['Subscribed Users'],
        'headings' => ["en" => "Alerta de Vencimiento"],
        'contents' => ["en" => $mensaje],
        'chrome_web_icon' => "https://farmacia.rf.gd/src"
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json; charset=utf-8",
        "Authorization: Basic $apiKey"
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_exec($ch);
    curl_close($ch);
}
