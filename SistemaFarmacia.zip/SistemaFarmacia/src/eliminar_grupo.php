<?php
include "../conexion.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query_delete = mysqli_query($conexion, "DELETE FROM grupos WHERE id = $id");

    if ($query_delete) {
        header('Location: grupos.php'); // Redirige de vuelta a la página de grupos
    } else {
        echo "Error al eliminar el grupo";
    }
}
?>
