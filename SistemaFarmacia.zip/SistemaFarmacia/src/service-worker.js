const CACHE_NAME = "dashboard-cache-v1";
const urlsToCache = [
    "./",
    "./index.php",
    "./assets/css/style.css",
    "./assets/css/material-dashboard.css",
    "./assets/js/material-dashboard.js",
    "./assets/img/logo.png"
];

// Instalación del SW y cache
self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(urlsToCache))
    );
});

// Activación del SW
self.addEventListener("activate", (event) => {
    event.waitUntil(self.clients.claim());
});

// Fetch: responder desde cache primero
self.addEventListener("fetch", (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => response || fetch(event.request))
    );
});

// Escuchar notificaciones push
self.addEventListener("push", function (event) {
    const data = event.data ? event.data.text() : 'Notificación de ejemplo';
    const options = {
        body: data,
        icon: 'assets/img/logo.png',
        badge: 'assets/img/logo.png'
    };
    event.waitUntil(self.registration.showNotification('Alerta de productos', options));
});