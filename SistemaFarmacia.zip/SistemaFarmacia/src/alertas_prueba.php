<?php
// alertas_prueba.php

// 🔹 Credenciales de OneSignal
$onesignal_app_id = "f5a9cab9-dafe-4e13-b93e-0548ca9b5632";
$onesignal_api_key = "bvg6bcxwweiofm32w6ycgpt3t"; // REST API KEY

// 🔹 Mensaje de prueba
$mensaje = "✅ Esta es una notificación de prueba desde Farmacia.";

$payload = [
    'app_id' => $onesignal_app_id,
    'included_segments' => ['All'],
    'headings' => ["en" => "Prueba de notificación"],
    'contents' => ["en" => $mensaje]
];

$ch = curl_init("https://onesignal.com/api/v1/notifications");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json; charset=utf-8',
    'Authorization: Basic ' . $onesignal_api_key
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
curl_close($ch);

// Puedes ver el resultado si deseas depuración
echo "✅ Notificación de prueba enviada.<br>";
echo "Respuesta: " . $response;
?>
