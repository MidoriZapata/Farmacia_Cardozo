<?php
include("../conexion.php");
header('Content-Type: application/json; charset=utf-8');

// Evitar caché (InfinityFree requiere esto)
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$hoy = date("Y-m-d");

// Consulta: productos por vencer, alerta manual o fecha_alerta
$sql = "SELECT idproducto, descripcion, vencimiento, fecha_alerta
        FROM producto
        WHERE 
            (vencimiento <= DATE_ADD('$hoy', INTERVAL 7 DAY) AND vencimiento >= '$hoy')
            OR (fecha_alerta = '$hoy')
            OR (alerta = 1)
        ORDER BY vencimiento ASC";

$result = mysqli_query($conexion, $sql);

if (!$result) {
    echo json_encode(["error" => mysqli_error($conexion)]);
    exit;
}

$alertas = [];
while ($row = mysqli_fetch_assoc($result)) {

    // Normalizar fechas
    $venc = $row['vencimiento'] ?: '0000-00-00';
    $alerta_fecha = $row['fecha_alerta'] ?: '0000-00-00';

    $dias = 999;
    if ($venc !== '0000-00-00') {
        $dias = (strtotime($venc) - strtotime($hoy)) / 86400;
    }

    // Mensaje que se enviará vía PUSHER
    if ($dias == 0) {
        $msg = "⚠️ Hoy vence: " . $row['descripcion'];
    } elseif ($dias > 0 && $dias <= 7) {
        $msg = "⏳ Próximo a vencer ($dias días): " . $row['descripcion'];
    } elseif ($alerta_fecha == $hoy) {
        $msg = "📌 Recordatorio: " . $row['descripcion'];
    } else {
        $msg = "⚠️ Alerta activada: " . $row
