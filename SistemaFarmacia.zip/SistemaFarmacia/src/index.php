<?php
require "../conexion.php";
session_start();
include_once "includes/header.php";

// ---------------------
// Contar datos
// ---------------------
$total = [];
$usuarios = mysqli_query($conexion, "SELECT * FROM usuario");
$total['usuarios'] = mysqli_num_rows($usuarios);

$clientes = mysqli_query($conexion, "SELECT * FROM cliente");
$total['clientes'] = mysqli_num_rows($clientes);

$productos = mysqli_query($conexion, "SELECT * FROM producto");
$total['productos'] = mysqli_num_rows($productos);

$ventas = mysqli_query($conexion, "SELECT * FROM ventas WHERE fecha > CURDATE()");
$total['ventas'] = mysqli_num_rows($ventas);


$hoy = date('Y-m-d'); // Fecha actual para consultas
?>

<!-- Content Row -->
<div class="row">
    <!-- Tarjetas de conteo -->
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
                <div class="card-icon"><i class="fas fa-user fa-2x"></i></div>
                <a href="usuarios.php" class="card-category text-warning font-weight-bold">Usuarios</a>
                <h3 class="card-title"><?php echo $total['usuarios']; ?></h3>
            </div>
            <div class="card-footer bg-warning text-white"></div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
                <div class="card-icon"><i class="fas fa-users fa-2x"></i></div>
                <a href="clientes.php" class="card-category text-success font-weight-bold">Clientes</a>
                <h3 class="card-title"><?php echo $total['clientes']; ?></h3>
            </div>
            <div class="card-footer bg-secondary text-white"></div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
                <div class="card-icon"><i class="fab fa-product-hunt fa-2x"></i></div>
                <a href="productos.php" class="card-category text-danger font-weight-bold">Productos</a>
                <h3 class="card-title"><?php echo $total['productos']; ?></h3>
            </div>
            <div class="card-footer bg-primary"></div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
                <div class="card-icon"><i class="fas fa-cash-register fa-2x"></i></div>
                <a href="ventas.php" class="card-category text-info font-weight-bold">Ventas</a>
                <h3 class="card-title"><?php echo $total['ventas']; ?></h3>
            </div>
            <div class="card-footer bg-danger text-white"></div>
        </div>
    </div>

    <!-- Sección Alertas -->
    <div class="card mt-4">
        <div class="card-header">
            <h4>Fecha de Alertas</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-warning table-bordered" id="tbl_alertas">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Tipo</th>
                            <th>Presentación</th>
                            <th>Fecha de Alerta</th>
                            <th>Fecha de Vencimiento</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query_alertas = mysqli_query($conexion, "SELECT p.*, t.tipo, pr.nombre 
                            FROM producto p 
                            INNER JOIN tipos t ON p.id_tipo = t.id 
                            INNER JOIN presentacion pr ON p.id_presentacion = pr.id 
                            WHERE DATE_SUB(p.vencimiento, INTERVAL 7 DAY) <= '$hoy' AND p.vencimiento > '$hoy'");
                        if (mysqli_num_rows($query_alertas) > 0) {
                            while ($data_alerta = mysqli_fetch_assoc($query_alertas)) { ?>
                                <tr>
                                    <td><?php echo $data_alerta['codproducto']; ?></td>
                                    <td><?php echo $data_alerta['codigo']; ?></td>
                                    <td><?php echo $data_alerta['descripcion']; ?></td>
                                    <td><?php echo $data_alerta['tipo']; ?></td>
                                    <td><?php echo $data_alerta['nombre']; ?></td>
                                    <td><?php echo $data_alerta['fecha_alerta']; ?></td>
                                    <td><?php echo $data_alerta['vencimiento']; ?></td>
                                    <td>
                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                            data-target="#modalConfirmarEditar<?php echo $data_alerta['codproducto']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <div class="modal fade"
                                            id="modalConfirmarEditar<?php echo $data_alerta['codproducto']; ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="modalLabelEditar" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header bg-warning text-white">
                                                        <h5 class="modal-title" id="modalLabelEditar">Confirmar edición</h5>
                                                        <button type="button" class="close text-white" data-dismiss="modal"
                                                            aria-label="Cerrar">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">¿Estás seguro de que quieres editar este producto?
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">No</button>
                                                        <a href="productos.php?id=<?php echo $data_alerta['codproducto']; ?>"
                                                            class="btn btn-primary">Sí, Editar</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="8" class="text-center">No hay alertas de vencimiento para mostrar</td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Productos Vencidos -->
    <div class="card mt-4">
        <div class="card-header">
            <h4>Productos vencidos</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-danger table-bordered" id="tbl">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Tipo</th>
                            <th>Presentación</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = mysqli_query($conexion, "SELECT p.*, t.tipo, pr.nombre 
                            FROM producto p 
                            INNER JOIN tipos t ON p.id_tipo = t.id 
                            INNER JOIN presentacion pr ON p.id_presentacion = pr.id 
                            WHERE p.vencimiento != '0000-00-00' AND p.vencimiento < '$hoy'");
                        if (mysqli_num_rows($query) > 0) {
                            while ($data = mysqli_fetch_assoc($query)) { ?>
                                <tr>
                                    <td><?php echo $data['codproducto']; ?></td>
                                    <td><?php echo $data['codigo']; ?></td>
                                    <td><?php echo $data['descripcion']; ?></td>
                                    <td><?php echo $data['tipo']; ?></td>
                                    <td><?php echo $data['nombre']; ?></td>
                                    <td><?php echo $data['precio']; ?></td>
                                    <td><?php echo $data['existencia']; ?></td>
                                    <td>
                                        <form action="eliminar_producto.php?id=<?php echo $data['codproducto']; ?>"
                                            method="post" class="confirmar d-inline">
                                            <button class="btn btn-danger" type="submit"><i
                                                    class='fas fa-trash-alt'></i></button>
                                        </form>
                                    </td>
                                </tr>
                        <?php }
                        } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Gráficos -->
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header card-header-primary">
                <h3 class="title-2 m-b-40">Productos con stock mínimo</h3>
            </div>
            <div class="card-body">
                <canvas id="stockMinimo"></canvas>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header card-header-primary">
                <h3 class="title-2 m-b-40">Productos más vendidos</h3>
            </div>
            <div class="card-body">
                <canvas id="ProductosVendidos"></canvas>
            </div>
        </div>
    </div>
</div>

<?php include_once "includes/footer.php"; ?>

<!-- 🔔 Notificaciones locales de vencimiento -->
<script>
    document.addEventListener("DOMContentLoaded", () => {
        // =============================
        // ✅ Registrar Service Worker
        // =============================
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('../sw.js')
                .then(() => console.log('✅ Service Worker registrado'))
                .catch(err => console.error('❌ Error registrando SW:', err));
        }

        // =============================
        // 💊 Verificar productos a vencer
        // =============================
        async function verificarVencimientos() {
            try {
                const res = await fetch("alerta_vencimiento.php", {
                    cache: "no-store"
                });
                const data = await res.json();

                if (data.length > 0) {
                    let mensaje = "Productos con alerta de vencimiento:\n\n";

                    data.forEach(p => {
                        const fechaV = formatearFecha(p.vencimiento);
                        const fechaA = formatearFecha(p.fecha_alerta);
                        mensaje += `💊 ${p.descripcion}\n📅 Vence: ${fechaV}\n⚠️ Alerta: ${fechaA}\n\n`;
                    });

                    // Mostrar notificación si hay permiso
                    if (Notification.permission === "granted") {
                        mostrarNotificacion(mensaje);
                    } else if (Notification.permission !== "denied") {
                        const permiso = await Notification.requestPermission();
                        if (permiso === "granted") mostrarNotificacion(mensaje);
                        else alert(mensaje); // fallback si usuario bloquea notificaciones
                    }


                }
            } catch (err) {
                console.error("Error al consultar vencimientos:", err);
            }
        }

        // =============================
        // 🔔 Mostrar notificación
        // =============================
        function mostrarNotificacion(mensaje) {
            if (navigator.serviceWorker) {
                navigator.serviceWorker.ready.then(reg => {
                    reg.showNotification("⚠️ Alerta de productos", {
                        body: mensaje,
                        icon: "assets/img/logo.png",
                        badge: "assets/img/logo.png",
                        requireInteraction: true
                    });
                });
            }
        }



        // =============================
        // 📅 Formatear fecha
        // =============================
        function formatearFecha(fechaISO) {
            if (!fechaISO || fechaISO === "0000-00-00") return "Sin fecha";
            const [anio, mes, dia] = fechaISO.split("-");
            return `${dia}/${mes}/${anio}`;
        }

        // =============================
        // 🚀 Inicializar
        // =============================
        verificarVencimientos();
        setInterval(verificarVencimientos, 5 * 60 * 1000); // cada 5 minutos
    });
</script>