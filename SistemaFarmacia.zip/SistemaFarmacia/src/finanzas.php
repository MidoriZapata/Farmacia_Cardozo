<?php
session_start();
if (empty($_SESSION['active'])) {
    header('Location: ../');
}

// Aquí puedes incluir la conexión a la base de datos
include "../conexion.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finanzas</title>
    <link href="../assets/css/material-dashboard.css" rel="stylesheet" />
    <link href="../assets/css/datatables.min.css" rel="stylesheet" />
</head>
<body>
    <div class="container mt-5">
        <h1>Historial de Finanzas</h1>
        <table id="tablaFinanzas" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Descripción</th>
                    <th>Monto</th>
                    <th>Fecha</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Aquí debes modificar la consulta para obtener datos de finanzas en lugar de ventas
                $query = mysqli_query($conexion, "SELECT * FROM finanzas");
                $result = mysqli_num_rows($query);

                if ($result > 0) {
                    while ($data = mysqli_fetch_assoc($query)) {
                ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['descripcion']; ?></td>
                    <td><?php echo $data['monto']; ?></td>
                    <td><?php echo $data['fecha']; ?></td>
                    <td>
                        <button class="btn btn-danger">
                            <i class="fas fa-file-pdf"></i>
                        </button>
                    </td>
                </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/datatables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tablaFinanzas').DataTable();
        });
    </script>
</body>
</html>
