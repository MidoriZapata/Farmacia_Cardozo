<?php
session_start();
require_once "../conexion.php";
$id_user = $_SESSION['idUser'];
$permiso = "ventas";

// Verificación de permisos
$sql = mysqli_query($conexion, "SELECT p.*, d.* FROM permisos p INNER JOIN detalle_permisos d ON p.id = d.id_permiso WHERE d.id_usuario = $id_user AND p.nombre = '$permiso'");
$existe = mysqli_fetch_all($sql);
if (empty($existe) && $id_user != 1) {
    header('Location: permisos.php');
}

// Filtrar ventas por fecha si se ha enviado el formulario
$fecha_inicio = isset($_POST['fecha_inicio']) ? $_POST['fecha_inicio'] : '';
$fecha_fin = isset($_POST['fecha_fin']) ? $_POST['fecha_fin'] : '';

// Consulta para obtener ventas con filtrado de fecha
$query = "SELECT v.*, c.idcliente, c.nombre FROM ventas v INNER JOIN cliente c ON v.id_cliente = c.idcliente";
if ($fecha_inicio && $fecha_fin) {
    $query .= " WHERE v.fecha BETWEEN '$fecha_inicio' AND '$fecha_fin'";
}
$query_result = mysqli_query($conexion, $query);

// Calcular el total de ganancias si hay filtro
$total_ganancia = 0;
if ($fecha_inicio && $fecha_fin) {
    $total_ganancia_query = mysqli_query($conexion, "SELECT SUM(total) as total_ganancia FROM ventas WHERE fecha BETWEEN '$fecha_inicio' AND '$fecha_fin'");
    $total_ganancia_result = mysqli_fetch_assoc($total_ganancia_query);
    $total_ganancia = $total_ganancia_result['total_ganancia'];
}

include_once "includes/header.php";
?>

<!-- Formulario para filtrar ventas por fecha -->
<form method="POST" class="form-inline mb-3">
    <label for="fecha_inicio" class="mr-2">Fecha Inicio:</label>
    <input type="date" name="fecha_inicio" id="fecha_inicio" class="form-control mr-2"
        value="<?php echo $fecha_inicio; ?>">
    <label for="fecha_fin" class="mr-2">Fecha Fin:</label>
    <input type="date" name="fecha_fin" id="fecha_fin" class="form-control mr-2" value="<?php echo $fecha_fin; ?>">
    <button type="submit" class="btn btn-primary">Filtrar</button>
</form>

<div class="card">
    <div class="card-header">
        Historial ventas
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-light" id="tbl">
                <thead class="thead-dark">
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Total</th>
                        <th>Fecha</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($query_result)) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['nombre']; ?></td>
                            <td>Bs. <?php echo $row['total']; ?></td>
                            <td><?php echo date('H:i:s d/m/Y', strtotime($row['fecha'])); ?></td>

                            <td>
                                <a href="pdf/generar.php?cl=<?php echo $row['id_cliente'] ?>&v=<?php echo $row['id'] ?>"
                                    target="_blank" class="btn btn-danger"><i class="fas fa-file-pdf"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <!-- Mostrar el total de ganancias si hay filtro de fecha -->
        <?php if ($fecha_inicio && $fecha_fin) { ?>
            <div class="text-right">
                <strong>Total de Ganancia: </strong><?php echo number_format($total_ganancia, 2); ?>
            </div>
        <?php } ?>
    </div>
</div>

<?php include_once "includes/footer.php"; ?>