<?php
// alertas_auto.php
// Ejecutado automáticamente por cron-job.org

include "../conexion.php";

// ========================
// CONFIGURACIÓN PUSHER
// ========================
require __DIR__ . "/../vendor/autoload.php"; // si usas Composer

$options = [
    'cluster' => 'us2',
    'useTLS' => true
];

$pusher = new Pusher\Pusher(
    "TU_KEY_AQUI",     // 🔴 PON TU KEY
    "TU_SECRET_AQUI",  // 🔴 PON TU SECRET
    "TU_APP_ID",       // 🔴 PON TU APP ID
    $options
);

// ========================
// FECHA ACTUAL
// ========================
$hoy = date('Y-m-d');

// ========================
// CONSULTA DE PRODUCTOS CON ALERTA
// ========================
$query = mysqli_query($conexion, "
    SELECT descripcion, vencimiento, fecha_alerta 
    FROM producto 
    WHERE 
        (fecha_alerta = '$hoy')
        OR (vencimiento <= DATE_ADD('$hoy', INTERVAL 7 DAY) AND vencimiento >= '$hoy')
        OR (alerta = 1)
");

if (!$query) {
    die('Error en consulta: ' . mysqli_error($conexion));
}

$alertas = [];
while ($row = mysqli_fetch_assoc($query)) {

    // Normalizar valores
    $descripcion = $row['descripcion'];
    $vencimiento = $row['vencimiento'] ?: "0000-00-00";
    $fecha_alerta = $row['fecha_alerta'] ?: "0000-00-00";

    // Calcular días restantes
    $dias = 999;
    if ($vencimiento !== "0000-00-00") {
        $dias = (strtotime($vencimiento) - strtotime($hoy)) / 86400;
    }

    // Crear mensaje
    if ($dias == 0) {
        $mensaje = "⚠️ Hoy vence: $descripcion";
    } elseif ($dias > 0 && $dias <= 7) {
        $mensaje = "⏳ $descripcion vence en $dias días";
    } elseif ($fecha_alerta == $hoy) {
        $mensaje = "📌 Recordatorio: $descripcion";
    } else {
        $mensaje = "⚠️ Alerta activa: $descripcion";
    }

    // Agregar alerta final
    $alertas[] = ["mensaje" => $mensaje];
}

// ========================
// ENVIAR ALERTAS A PUSHER
// ========================
if (count($alertas) > 0) {

    foreach ($alertas as $alerta) {
        $pusher->trigger("alertas-channel", "nueva-alerta", [
            "mensaje" => $alerta["mensaje"]
        ]);
    }

    echo "✅ Alertas enviadas correctamente.";
} else {
    echo "No hay alertas por enviar.";
}

mysqli_close($conexion);
?>
