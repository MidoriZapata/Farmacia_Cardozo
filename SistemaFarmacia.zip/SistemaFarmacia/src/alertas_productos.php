<?php
include("../conexion.php");  // Asegúrate que la ruta es correcta

$fecha_hoy = date("Y-m-d");

// Buscar productos cuya fecha_alerta ya llegó o pasó
$query_alerta = mysqli_query($conexion, "
    SELECT descripcion, codigo, fecha_alerta 
    FROM producto 
    WHERE fecha_alerta IS NOT NULL
    AND fecha_alerta != '0000-00-00'
    AND fecha_alerta <= '$fecha_hoy'
    ORDER BY fecha_alerta ASC
");
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alertas de Productos</title>

    <!-- CSS personalizado -->
    <link rel="stylesheet" href="/assets/css/alertas.css">

    <!-- Bootstrap (opcional para el diseño si ya lo usas) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<div class="container mt-4">

<?php
if (mysqli_num_rows($query_alerta) > 0) {
    echo '
    <div class="alert-container">
        <div class="alert alert-warning fw-bold" role="alert">
            ⚠️ Productos con fecha de alerta alcanzada
        </div>
        <ul class="list-group">
    ';

    while ($producto_alerta = mysqli_fetch_assoc($query_alerta)) {
        $descripcion = $producto_alerta['descripcion'];
        $codigo = $producto_alerta['codigo'];
        $fecha = $producto_alerta['fecha_alerta'];

        echo '
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <span><strong>' . $descripcion . '</strong> (Código: ' . $codigo . ')</span>
                <span class="badge bg-danger">Alerta: ' . $fecha . '</span>
            </li>
        ';
    }

    echo "
        </ul>
    </div>";
} else {
    echo '
        <div class="alert alert-success text-center">
            ✔ No hay productos con alerta activa.
        </div>
    ';
}
?>

</div>

</body>
</html>
